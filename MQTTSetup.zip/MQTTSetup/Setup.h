#ifndef Setup_h
#define Setup_h
#endif

#include <PubSubClient.h>
#include <WiFi.h>

#define WIFI_SSID "WIFISSID"       // Replace this with YOUR WiFi SSID
#define WIFI_PASSWORD "WIFIPASSWORD" // Replace this with YOUR WiFi Password

#define MQTT_SERVER "VmExternalIp"
#define MQTT_PORT 1883
#define MQTT_TOPIC "iot"